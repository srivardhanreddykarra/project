let searchInputEl = document.getElementById("searchInput");
let searchResultsEl = document.getElementById("searchResults");
let spinnerEl = document.getElementById("spinner");

function createAndAppending(result) {
    let {
        link,
        title,
        description
    } = result;

    let containerEl = document.createElement("div");
    containerEl.classList.add("result-item");

    let titleEl = document.createElement("a");
    titleEl.href = link;
    titleEl.textContent = title;
    titleEl.target = "_blank";
    titleEl.classList.add("result-title");
    containerEl.appendChild(titleEl);

    let brEl = document.createElement('br');
    containerEl.appendChild(brEl);

    let linkEl = document.createElement("a");
    linkEl.textContent = link;
    linkEl.href = link;
    linkEl.target = "_blank";
    linkEl.classList.add("result-url");
    containerEl.appendChild(linkEl);


    let linkbrEl = document.createElement('br');
    containerEl.appendChild(linkbrEl);

    let paraEl = document.createElement("p");
    paraEl.classList.add("link-description");
    paraEl.textContent = description;
    containerEl.appendChild(paraEl);
    searchResultsEl.appendChild(containerEl);


}

function displayResultsOf(search_results) {
    spinnerEl.classList.toggle("d-none")
    for (let result of search_results) {
        createAndAppending(result);
    }
}



function searchValue(event) {
    if (event.key === "Enter") {
        searchResultsEl.textContent = ""
        spinnerEl.classList.toggle("d-none")
        let searchInput = searchInputEl.value;
        let url = "https://apis.ccbp.in/wiki-search?search=" + searchInput;
        let options = {
            method: "GET",
        }
        fetch(url, options)
            .then(function(response) {
                return response.json()
            })
            .then(function(jsonData) {
                let {
                    search_results
                } = jsonData;
                displayResultsOf(search_results)
            });

    }
}



searchInputEl.addEventListener("keydown", searchValue);