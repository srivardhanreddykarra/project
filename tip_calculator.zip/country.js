let billAmount = document.getElementById("billAmount");
let percentagetip = document.getElementById("percentageTip");
let tipamount = document.getElementById("tipAmount");
let totalvalue = document.getElementById("totalAmount");
let errorMessageElement = document.getElementById("errorMessage");

function calculateButton() {
    let billAmountInput = billAmount.value;
    let perInput = percentagetip.value;

    if (billAmountInput === "") {
        errorMessageElement.textContent = "Please Enter a Valid Input";
    } else if (perInput === "") {
        errorMessageElement.textContent = "Please Enter a Valid Input"
    } else {
        errorMessageElement.textContent = "";
        let bill = parseInt(billAmountInput);
        let per = parseInt(perInput);
        let calculatedTip = (per / 100) * bill;
        let calculatedTotal = bill + calculatedTip;
        tipamount.value = calculatedTip;
        totalvalue.value = calculatedTotal;
    }
}